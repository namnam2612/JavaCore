package vn.com.claim.claim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimApplicationTests {

	@Test
	void contextLoads() {
	}

}
